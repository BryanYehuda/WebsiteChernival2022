$(document).ready(() => {
  $(document).click(() => {
    $('.navbar-collapse').collapse('hide');
  });
});
